package com.jarvis.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

const val MODEL = "gemini-2.5-flash"
const val GEMINI_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

fun securePrefs(ctx: Context) = EncryptedSharedPreferences.create(
    ctx, "secure",
    MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
)

fun askGemini(key: String, history: List<Pair<String, String>>): String {
    val contents = JSONArray()
    history.forEach { (role, text) ->
        val geminiRole = if (role == "user") "user" else "model"
        contents.put(
            JSONObject()
                .put("role", geminiRole)
                .put("parts", JSONArray().put(JSONObject().put("text", text)))
        )
    }

    val body = JSONObject()
        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(
            JSONObject().put(
                "text",
                "You are Jarvis, a helpful voice assistant. Reply in the same language the user speaks (Gujarati, Hindi or English). Keep answers short and spoken-friendly."
            )
        )))
        .put("contents", contents)
        .put("generationConfig", JSONObject().put("maxOutputTokens", 1000))

    val url = URL("$GEMINI_ENDPOINT?key=${java.net.URLEncoder.encode(key, "UTF-8")}")
    val c = url.openConnection() as HttpURLConnection
    c.requestMethod = "POST"
    c.setRequestProperty("Content-Type", "application/json")
    c.doOutput = true
    c.connectTimeout = 20000
    c.readTimeout = 60000

    c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
    val code = c.responseCode
    val text = (if (code in 200..299) c.inputStream else c.errorStream)
        .bufferedReader().use { it.readText() }

    if (code !in 200..299) return "Gemini Error $code: $text"

    val json = JSONObject(text)
    val candidates = json.optJSONArray("candidates")
        ?: return "Gemini e koi response aapyo nathi."
    if (candidates.length() == 0) return "Gemini e koi response aapyo nathi."

    val parts = candidates.getJSONObject(0)
        .optJSONObject("content")
        ?.optJSONArray("parts")
        ?: return "Gemini e koi text response aapyo nathi."

    return buildString {
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i)
            val t = part?.optString("text", "") ?: ""
            if (t.isNotBlank()) append(t)
        }
    }.ifBlank { "Gemini e blank response aapyo." }
}

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF00E5FF),
                    background = Color(0xFF05070D),
                    surface = Color(0xFF0D1220),
                    onBackground = Color(0xFFE6F1FF),
                    onSurface = Color(0xFFE6F1FF)
                )
            ) {
                JarvisScreen { text, lang ->
                    tts?.language = Locale.forLanguageTag(lang)
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
                }
            }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisScreen(speak: (String, String) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { securePrefs(ctx) }
    val messages = remember { mutableStateListOf<Pair<String, String>>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var lang by remember { mutableStateOf(prefs.getString("lang", "gu-IN") ?: "gu-IN") }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    fun send(text: String) {
        if (text.isBlank() || busy) return
        messages.add("user" to text)
        input = ""
        busy = true
        scope.launch {
            val key = prefs.getString("key", "") ?: ""
            val reply = if (key.isBlank()) "Pehla Settings ma Gemini API key nakho."
            else try {
                withContext(Dispatchers.IO) { askGemini(key, messages.toList()) }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            messages.add("assistant" to reply)
            busy = false
            speak(reply, lang)
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (t != null) send(t)
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().imePadding().padding(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("JARVIS", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            TextButton(onClick = { showSettings = true }) { Text("⚙️ Settings") }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { (role, text) ->
                val mine = role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Surface(
                        color = if (mine) Color(0xFF00394A) else MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(14.dp)
                    ) { Text(text, Modifier.padding(12.dp)) }
                }
            }
            if (busy) item { Text("…", color = MaterialTheme.colorScheme.primary) }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Lakho athva bolo…") }
            )
            Spacer(Modifier.width(6.dp))
            Button(onClick = {
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                try { speechLauncher.launch(i) } catch (e: ActivityNotFoundException) {
                    messages.add("assistant" to "Phone ma voice recognition (Google app) nathi.")
                }
            }) { Text("🎤") }
            Spacer(Modifier.width(6.dp))
            Button(onClick = { send(input) }) { Text("➤") }
        }
    }

    if (showSettings) {
        var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
        var l by remember { mutableStateOf(lang) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Settings") },
            text = {
                Column {
                    OutlinedTextField(
                        value = key, onValueChange = { key = it },
                        label = { Text("Gemini API key") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    Spacer(Modifier.height(12.dp))
                    listOf("gu-IN" to "ગુજરાતી", "hi-IN" to "हिन्दी", "en-IN" to "English").forEach { (code, name) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = l == code, onClick = { l = code })
                            Text(name)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    prefs.edit().putString("key", key.trim()).putString("lang", l).apply()
                    lang = l
                    showSettings = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
        )
    }
}
